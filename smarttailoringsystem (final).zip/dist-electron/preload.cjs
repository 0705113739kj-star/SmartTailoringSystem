var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// electron/preload.ts
var preload_exports = {};
module.exports = __toCommonJS(preload_exports);
var import_electron = require("electron");
var desktopBridge = {
  isElectron: true,
  platform: process.platform,
  getAppInfo: () => import_electron.ipcRenderer.invoke("desktop:get-app-info"),
  createBackup: (businessId) => import_electron.ipcRenderer.invoke("desktop:create-backup", { businessId }),
  pickAndValidateBackup: () => import_electron.ipcRenderer.invoke("desktop:pick-and-validate-backup"),
  restoreBackup: (filePath) => import_electron.ipcRenderer.invoke("desktop:restore-backup", { filePath }),
  saveFile: (options) => import_electron.ipcRenderer.invoke("desktop:save-file", {
    defaultPath: options.defaultPath,
    data: Array.from(options.data),
    filters: options.filters
  }),
  nativePrint: () => import_electron.ipcRenderer.invoke("desktop:print"),
  openExternal: (url) => import_electron.ipcRenderer.invoke("desktop:open-external", { url })
};
import_electron.contextBridge.exposeInMainWorld("smartTailoringDesktop", desktopBridge);
